package com.skinora.skinorabackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkinoraApplicationTests {

    @Test
    void contextLoads() {
    }

}
