package com.skinora.skinorabackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkinoraApplication {

    public static void main(String[] args) {
        SpringApplication.run(SkinoraApplication.class, args);
    }

}
