package com.skinora.skinorabackend.controller;

import com.skinora.skinorabackend.entity.Device;
import com.skinora.skinorabackend.service.DeviceService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/devices")
@RequiredArgsConstructor
public class DeviceController {

    private final DeviceService deviceService;

    // Отримати пристрій за серійним номером
    @GetMapping("/serial/{serialNumber}")
    public Optional<Device> getDeviceBySerialNumber(@PathVariable Integer serialNumber) {
        return deviceService.getDeviceBySerialNumber(serialNumber);
    }
}
