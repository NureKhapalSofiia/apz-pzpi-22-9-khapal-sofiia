package com.skinora.skinorabackend.controller;

import com.skinora.skinorabackend.entity.User;
import com.skinora.skinorabackend.service.AuthService;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@AllArgsConstructor
public class AuthController {

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class RegisterRequest {
        private String name;
        private String email;
        private String password;
        private String roleName;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class LogInRequest {
        private String email;
        private String password;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TokenResponse {
        private String token;
    }

    // ИСПРАВЛЕНО: Новый класс для ответа с токеном и данными пользователя
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AuthResponse {
        private String token;
        private UserInfo user;
    }

    // ИСПРАВЛЕНО: Класс для информации о пользователе в ответе
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class UserInfo {
        private int id;
        private String email;
        private String passwordHash;
        private String fullName;
        private String avatarUrl;
        private RoleInfo role;
        private boolean active;
        private String createdAt;
        private String updatedAt;
    }

    // ИСПРАВЛЕНО: Класс для информации о роли
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RoleInfo {
        private int id;
        private String name;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class UserResponse {
        private int id;
        private String email;
        private String role;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RoleResponse {
        private String role;
        private int roleId;
    }

    private final AuthService authService;

    // Регистрация пользователя
    @PostMapping("/register")
    public UserResponse register (@RequestBody RegisterRequest request){
        var user = authService.registerUser(request.getName(), request.getEmail(), request.getPassword(), request.getRoleName());
        return new UserResponse(user.getId(), user.getEmail(), user.getRole().getName());
    }

    // ИСПРАВЛЕНО: Аутентификация пользователя - теперь возвращает токен и данные пользователя
    @PostMapping("/login")
    public AuthResponse login (@RequestBody LogInRequest request){
        System.out.println("Email: " + request.getEmail());
        System.out.println("Password: " + request.getPassword());


        // Получаем токен и пользователя
        String token = authService.authenticateUser(request.getEmail(), request.getPassword());
        User user = authService.getUserByEmail(request.getEmail());

        // Создаем объект с информацией о пользователе
        UserInfo userInfo = new UserInfo(
                user.getId(),
                user.getEmail(),
                user.getPasswordHash(),
                user.getFullName(),
                user.getAvatarUrl(),
                new RoleInfo(user.getRole().getId(), user.getRole().getName()),
                user.isActive(),
                user.getCreatedAt().toString(),
                user.getUpdatedAt().toString()
        );

        return new AuthResponse(token, userInfo);
    }

    // ИСПРАВЛЕНО: Получить роль пользователя по email - теперь возвращает roleId
    @GetMapping("/role")
    public RoleResponse getRole(@RequestParam String email){
        User user = authService.getUserByEmail(email);
        return new RoleResponse(user.getRole().getName(), user.getRole().getId());
    }
}