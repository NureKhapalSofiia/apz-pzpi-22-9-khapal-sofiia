package com.skinora.skinorabackend.repository;

import com.skinora.skinorabackend.entity.Appointment;
import com.skinora.skinorabackend.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {

    List<Appointment> findByPatientId(Integer patientId);
    List<Appointment> findByDoctorId(Integer doctorId);
    List<Appointment> findByDoctorIdAndDatetimeBetween(Integer doctorId, LocalDateTime start, LocalDateTime end);
    Optional<Appointment> findByIdAndPatientId(Integer id, Integer patientId);

    void deleteByDoctorId(@Param("id") Integer id);


}
