package com.skinora.skinorabackend.service;

import com.skinora.skinorabackend.entity.Appointment;
import com.skinora.skinorabackend.entity.Patient;
import com.skinora.skinorabackend.entity.Doctor;
import com.skinora.skinorabackend.repository.AppointmentRepository;
import com.skinora.skinorabackend.repository.PatientRepository;
import com.skinora.skinorabackend.repository.DoctorRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@Transactional
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;

    public AppointmentService(AppointmentRepository appointmentRepository,
                              PatientRepository patientRepository,
                              DoctorRepository doctorRepository) {
        this.appointmentRepository = appointmentRepository;
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
    }

    //Отримати всі записи пацієнта
    @Transactional(readOnly = true)
    public List<Appointment> getAppointmentsByPatient(Integer patientId) {
        System.out.println("AppointmentService.getAppointmentsByPatient() called for patientId: " + patientId);

        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new RuntimeException("Patient not found with id: " + patientId));

        List<Appointment> appointments = appointmentRepository.findByPatientId(patientId);
        System.out.println("AppointmentService: found " + appointments.size() + " appointments for patient " + patientId);
        return appointments;
    }

    //Отримати всі записи лікаря
    @Transactional(readOnly = true)
    public List<Appointment> getAppointmentsByDoctor(Integer doctorId) {
        System.out.println("AppointmentService.getAppointmentsByDoctor() called for doctorId: " + doctorId);

        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new RuntimeException("Doctor not found with id: " + doctorId));

        List<Appointment> appointments = appointmentRepository.findByDoctorId(doctorId);
        System.out.println("AppointmentService: found " + appointments.size() + " appointments for doctor " + doctorId);
        return appointments;
    }

    //Створити запис (новый метод с отдельными параметрами)
    public Appointment createAppointment(Integer patientId, Integer doctorId, String datetimeStr, String notes, String status) {
        System.out.println("==========================================");
        System.out.println("AppointmentService.createAppointment() called");
        System.out.println("PatientId: " + patientId);
        System.out.println("DoctorId: " + doctorId);
        System.out.println("DateTime string: " + datetimeStr);
        System.out.println("Notes: " + notes);
        System.out.println("Status: " + status);

        try {
            // Проверяем входные параметры
            if (patientId == null) {
                throw new RuntimeException("PatientId cannot be null");
            }
            if (doctorId == null) {
                throw new RuntimeException("DoctorId cannot be null");
            }
            if (datetimeStr == null || datetimeStr.trim().isEmpty()) {
                throw new RuntimeException("DateTime cannot be null or empty");
            }

            // Получаем пациента
            System.out.println("Looking for patient with id: " + patientId);
            Patient patient = patientRepository.findById(patientId)
                    .orElseThrow(() -> new RuntimeException("Patient not found with id: " + patientId));
            System.out.println("Found patient: " + patient.getUser().getFullName());

            // Получаем доктора
            System.out.println("Looking for doctor with id: " + doctorId);
            Doctor doctor = doctorRepository.findById(doctorId)
                    .orElseThrow(() -> new RuntimeException("Doctor not found with id: " + doctorId));
            System.out.println("Found doctor: " + doctor.getUser().getFullName());

            // Парсим datetime из ISO строки
            LocalDateTime datetime;
            try {
                System.out.println("Parsing datetime: " + datetimeStr);
                // Поддерживаем формат "2025-06-07T14:30:00"
                datetime = LocalDateTime.parse(datetimeStr, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
                System.out.println("Parsed datetime: " + datetime);
            } catch (Exception e) {
                System.err.println("Error parsing datetime: " + datetimeStr + ", error: " + e.getMessage());
                throw new RuntimeException("Invalid datetime format: " + datetimeStr + ". Expected format: yyyy-MM-ddTHH:mm:ss");
            }

            // Создаем запись
            System.out.println("Creating appointment entity...");
            Appointment appointment = Appointment.builder()
                    .patient(patient)
                    .doctor(doctor)
                    .datetime(datetime)
                    .notes(notes != null ? notes : "")
                    .status(status != null ? status : "PENDING")
                    .build();

            System.out.println("Saving appointment to database...");
            Appointment savedAppointment = appointmentRepository.save(appointment);

            System.out.println("Appointment created successfully!");
            System.out.println("Appointment ID: " + savedAppointment.getId());
            System.out.println("Patient: " + savedAppointment.getPatient().getUser().getFullName());
            System.out.println("Doctor: " + savedAppointment.getDoctor().getUser().getFullName());
            System.out.println("DateTime: " + savedAppointment.getDatetime());
            System.out.println("Status: " + savedAppointment.getStatus());
            System.out.println("==========================================");

            return savedAppointment;

        } catch (Exception e) {
            System.err.println("ERROR in AppointmentService.createAppointment:");
            System.err.println("Error message: " + e.getMessage());
            System.err.println("Error class: " + e.getClass().getSimpleName());
            e.printStackTrace();
            throw e; // Перебрасываем ошибку дальше
        }
    }

    //Створити запис (старый метод для обратной совместимости)
    public void createAppointment(Appointment appointment) {
        System.out.println("AppointmentService.createAppointment(entity) called");
        appointmentRepository.save(appointment);
    }

    //Скасувати запис
    public void cancelAppointment(Integer appointmentId) {
        System.out.println("AppointmentService.cancelAppointment() called for appointmentId: " + appointmentId);

        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found with id: " + appointmentId));

        appointment.setStatus("CANCELLED");
        appointmentRepository.save(appointment);

        System.out.println("AppointmentService: appointment " + appointmentId + " cancelled");
    }

    //Підтвердити запис
    public void confirmAppointment(Integer appointmentId) {
        System.out.println("AppointmentService.confirmAppointment() called for appointmentId: " + appointmentId);

        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found with id: " + appointmentId));

        appointment.setStatus("CONFIRMED");
        appointmentRepository.save(appointment);

        System.out.println("AppointmentService: appointment " + appointmentId + " confirmed");
    }
}