package com.skinora.skinorabackend.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="chats")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Chat {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    // ИСПРАВЛЕНО: ManyToOne вместо OneToOne, так как один пациент может иметь много чатов
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "participant_1_id", nullable = false)
    private Patient participant1;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "participant_2_id", nullable = false)
    private Doctor participant2;
}