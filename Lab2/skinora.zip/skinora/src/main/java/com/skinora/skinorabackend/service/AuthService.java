package com.skinora.skinorabackend.service;

import com.skinora.skinorabackend.entity.Doctor;
import com.skinora.skinorabackend.entity.Patient;
import com.skinora.skinorabackend.entity.Role;
import com.skinora.skinorabackend.entity.User;
import com.skinora.skinorabackend.repository.DoctorRepository;
import com.skinora.skinorabackend.repository.PatientRepository;
import com.skinora.skinorabackend.repository.RoleRepository;
import com.skinora.skinorabackend.repository.UserRepository;
import com.skinora.skinorabackend.security.JwtService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;

    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthService(UserRepository userRepository, PatientRepository patientRepository, DoctorRepository doctorRepository, RoleRepository roleRepository, PasswordEncoder passwordEncoder, JwtService jwtService) {
        this.userRepository = userRepository;
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    //Реєстрація
    public User registerUser(String fullName, String email, String password, String roleName) {
        if (userRepository.findByEmail(email).isPresent()) {
            throw new RuntimeException("User with email " + email + " already exists");
        }

        Role role = roleRepository.findByName(roleName)
                .orElseThrow(() -> new RuntimeException("Role " + roleName + " not found"));

        User newUser = new User();
        newUser.setFullName(fullName);
        newUser.setEmail(email);
        newUser.setPasswordHash(passwordEncoder.encode(password));
        newUser.setRole(role);
        newUser.setAvatarUrl("");
        newUser.setActive(true);

        userRepository.save(newUser);

        if ("patient".equalsIgnoreCase(roleName)) {
            Patient patient = new Patient();
            patient.setUser(newUser);
            patient.setGender("Не вказано");
            patient.setBirthDate(LocalDate.of(2000, 1, 1));
            patient.setNotes("Пацієнт зареєстрований");
            Doctor doctor = doctorRepository.findById(9)
                    .orElseThrow(() -> new RuntimeException("Default doctor not found"));
            patient.setDoctor(doctor);

            patientRepository.save(patient);
        }else if ("doctor".equalsIgnoreCase(roleName)) {
            Doctor doctor = new Doctor();
            doctor.setUser(newUser);
            doctor.setSpecialization("Не вказано");
            doctor.setExpirienceYears(0);
            doctorRepository.save(doctor);
        }
        return newUser;
    }

    // ИСПРАВЛЕНО: Добавлен метод для получения пользователя по email
    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User " + email + " not found"));
    }

    //Отримання ролі за Email
    public String getUserRole(String email) {
        User user = getUserByEmail(email);
        return user.getRole().getName();
    }

    //Аутентифікація користувача
    public String authenticateUser(String email, String password) {
        User user = getUserByEmail(email);

        if (!passwordEncoder.matches(password, user.getPasswordHash())) {
            throw new RuntimeException("Wrong password");
        }

        return jwtService.generateToken(user.getEmail());
    }
}