package com.skinora.skinorabackend.controller;

import com.skinora.skinorabackend.entity.Chat;
import com.skinora.skinorabackend.entity.Message;
import com.skinora.skinorabackend.service.ChatService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/chats")
@RequiredArgsConstructor
public class ChatController {

    private final ChatService chatService;

    // DTO для отправки сообщения (соответствует клиентскому SendMessageRequest)
    @Data
    public static class SendMessageRequest {
        private String message;
        private Integer senderId;
    }

    // Отримати всі чати пацієнта
    @GetMapping("/patient/{patientId}")
    public ResponseEntity<List<Chat>> getChatsByPatient(@PathVariable Integer patientId) {
        try {
            List<Chat> chats = chatService.getChatsByPatient(patientId);
            return ResponseEntity.ok(chats);
        } catch (Exception e) {
            System.err.println("Error getting chats for patient " + patientId + ": " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    // Отримати чат пацієнта з конкретним лікарем
    @GetMapping("/patient/{patientId}/doctor/{doctorId}")
    public ResponseEntity<Chat> getChatByPatientAndDoctor(@PathVariable Integer patientId,
                                                          @PathVariable Integer doctorId) {
        try {
            Chat chat = chatService.getChatByPatientAndDoctor(patientId, doctorId);
            return ResponseEntity.ok(chat);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            System.err.println("Error getting chat for patient " + patientId + " and doctor " + doctorId + ": " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    // Отримати всі повідомлення чату
    @GetMapping("/{chatId}/messages")
    public ResponseEntity<List<Message>> getMessagesByChat(@PathVariable Integer chatId) {
        try {
            List<Message> messages = chatService.getMessagesByChat(chatId);
            return ResponseEntity.ok(messages);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            System.err.println("Error getting messages for chat " + chatId + ": " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    // Надіслати повідомлення в чат
    @PostMapping("/{chatId}/messages")
    public ResponseEntity<Message> sendMessage(@PathVariable Integer chatId,
                                               @RequestBody SendMessageRequest request) {
        try {
            System.out.println("Received message request: " + request.getMessage() + " from sender: " + request.getSenderId());

            // Создаем объект Message из запроса
            Message message = Message.builder()
                    .message(request.getMessage())
                    .senderId(request.getSenderId())
                    .chatId(chatId)
                    .isRead(false)
                    .build();

            Message savedMessage = chatService.sendMessage(chatId, message);
            return ResponseEntity.ok(savedMessage);
        } catch (RuntimeException e) {
            System.err.println("Error sending message to chat " + chatId + ": " + e.getMessage());
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            System.err.println("Error sending message to chat " + chatId + ": " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    // Дополнительный эндпоинт для создания чата
    @PostMapping("/create")
    public ResponseEntity<Chat> createChat(@RequestParam Integer patientId, @RequestParam Integer doctorId) {
        try {
            Chat chat = chatService.createChat(patientId, doctorId);
            return ResponseEntity.ok(chat);
        } catch (RuntimeException e) {
            System.err.println("Error creating chat for patient " + patientId + " and doctor " + doctorId + ": " + e.getMessage());
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            System.err.println("Error creating chat: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    // Тестовый эндпоинт
    @GetMapping("/test")
    public ResponseEntity<String> test() {
        return ResponseEntity.ok("Chat controller is working!");
    }
}