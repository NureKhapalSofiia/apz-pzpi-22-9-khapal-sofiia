package com.skinora.skinorabackend.repository;

import com.skinora.skinorabackend.entity.Chat;
import com.skinora.skinorabackend.entity.Message;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MessageRepository extends JpaRepository<Message, Integer> {

    void deleteAllByChatId(Integer chatId);

    // Найти сообщения по chatId и отсортировать по времени отправки
    @Query("SELECT m FROM Message m WHERE m.chatId = :chatId ORDER BY m.sentAt ASC")
    List<Message> findByChatIdOrderBySentAt(@Param("chatId") Integer chatId);

    // Найти сообщения по Chat entity (если нужно)
    List<Message> findByChatOrderBySentAt(Chat chat);

    // Найти непрочитанные сообщения по chatId
    @Query("SELECT m FROM Message m WHERE m.chatId = :chatId AND m.isRead = false ORDER BY m.sentAt ASC")
    List<Message> findUnreadMessagesByChatId(@Param("chatId") Integer chatId);

    // Подсчет непрочитанных сообщений
    @Query("SELECT COUNT(m) FROM Message m WHERE m.chatId = :chatId AND m.isRead = false")
    Long countUnreadMessagesByChatId(@Param("chatId") Integer chatId);
}