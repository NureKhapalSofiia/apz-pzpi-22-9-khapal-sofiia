from locust import HttpUser, task, between

class SkinoraUser(HttpUser):
    wait_time = between(1, 2)


    @task
    def get_patients(self):
        self.client.get("/api/public/products")
