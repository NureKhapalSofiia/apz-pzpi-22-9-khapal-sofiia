import React, { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";

import LoginPage from "./assets/components/LoginPage";
import ProductsPage from "./assets/components/ProductsPage";
import AddProductPage from "./assets/components/AddProductForm";
import EditProductPage from "./assets/components/EditProductPage";
import DoctorsPage from "./assets/components/DoctorsPage";
import EditDoctorPage from "./assets/components/EditDoctorPage";
import PatientsPage from "./assets/components/PatientsPage";
import PatientDetailPage from "./assets/components/PatientDetailPage";
import DoctorProductsPage from "./assets/components/DoctorProductsPage"; 
import DoctorPatientsPage from "./assets/components/DoctorPatientsPage";
import AddRecommendationPage from "./assets/components/AddRecommendationPage";
import AddMeasurementPage from "./assets/components/AddMeasurementPage";
import EditNotePage from "./assets/components/EditNotePage";



function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const userInfo = localStorage.getItem("userInfo");
    if (token && userInfo) {
      setIsLoggedIn(true);
      const parsed = JSON.parse(userInfo);
      setUserRole(parsed.role?.name || null);
    }
  }, []);

  const handleLogin = async ({ email, password }) => {
    try {
      const response = await fetch("http://localhost:8080/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      if (response.ok) {
        const text = await response.text();
        const data = text ? JSON.parse(text) : {};

        localStorage.setItem("token", data.token);
        localStorage.setItem("userInfo", JSON.stringify(data.user));

        setIsLoggedIn(true);
        setUserRole(data.user.role?.name || null);
      } else {
        const errorText = await response.text();
        const err = errorText ? JSON.parse(errorText) : { message: "Невідомо" };
        alert(err.message || "Невірний email або пароль");
      }
    } catch (error) {
      alert("Помилка при вході: " + error.message);
    }
  };

const getRedirectPath = () => {
  if (userRole === "doctor") return "/doctor/patients";
  return "/products";
};


  return (
    <Router>
      <Routes>
        <Route
          path="/"
          element={
            isLoggedIn ? <Navigate to={getRedirectPath()} /> : <LoginPage onLogin={handleLogin} />
          }
        />

        <Route
          path="/products"
          element={isLoggedIn ? <ProductsPage /> : <Navigate to="/" />}
        />
        <Route
          path="/add-product"
          element={isLoggedIn ? <AddProductPage /> : <Navigate to="/" />}
        />
        <Route
          path="/products/edit/:id"
          element={isLoggedIn ? <EditProductPage /> : <Navigate to="/" />}
        />

        <Route
          path="/doctors"
          element={isLoggedIn ? <DoctorsPage /> : <Navigate to="/" />}
        />
        <Route
          path="/doctors/edit/:id"
          element={isLoggedIn ? <EditDoctorPage /> : <Navigate to="/" />}
        />

        <Route
          path="/patients"
          element={isLoggedIn ? <PatientsPage /> : <Navigate to="/" />}
        />
        <Route
          path="/patients/:id"
          element={isLoggedIn ? <PatientDetailPage /> : <Navigate to="/" />}
        />

        <Route
          path="/doctor/products"
          element={isLoggedIn && userRole === "doctor" ? <DoctorProductsPage /> : <Navigate to="/" />}
        />
        
        <Route
          path="/doctor/patients"
          element={isLoggedIn && userRole === "doctor" ? <DoctorPatientsPage /> : <Navigate to="/" />}
        />
        <Route path="/patients/:patientId/add-recommendation" element={<AddRecommendationPage />} />

        <Route
          path="/patients/:patientId/add-measurement"
          element={<AddMeasurementPage />}
        />
        <Route path="/patients/:patientId/edit-note" element={<EditNotePage />} />


      </Routes>

      
    </Router>
  );
}

export default App;
