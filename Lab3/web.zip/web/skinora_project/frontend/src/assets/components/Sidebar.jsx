// src/components/Sidebar.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import LogoutModal from "../components/LogoutModal";
import "../styles/LogoutModal.css";
import "../styles/products.css";

export default function Sidebar({ active, setActive }) {
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(false);
  const [role, setRole] = useState(null);

  useEffect(() => {
    const userInfo = localStorage.getItem("userInfo");
    if (userInfo) {
      const parsed = JSON.parse(userInfo);
      setRole(parsed.role?.name || null);
    }
  }, []);

  const handleLogoutConfirm = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userInfo");
    window.location.href = "/";
  };

  return (
    <>
      <div className="sidebar-background">
        <aside className="sidebar sidebar-full"
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            height: "100%",
          }}
        >
          <div>
            {role === "admin" && (
              <>
                <div
                  className={`sidebar-item ${active === "products" ? "active" : ""}`}
                  onClick={() => {
                    if (active !== "products") {
                      setActive("products");
                      navigate("/products");
                    }
                  }}
                >
                  Косметичні засоби
                </div>

                <div
                  className={`sidebar-item ${active === "patients" ? "active" : ""}`}
                  onClick={() => {
                    setActive("patients");
                    navigate("/patients");
                  }}
                >
                  Пацієнти
                </div>

                <div
                  className={`sidebar-item ${active === "doctors" ? "active" : ""}`}
                  onClick={() => {
                    setActive("doctors");
                    navigate("/doctors");
                  }}
                >
                  Лікарі
                </div>
              </>
            )}

            {role === "doctor" && (
              <>
                <div
                  className={`sidebar-item ${active === "products" ? "active" : ""}`}
                  onClick={() => {
                    setActive("products");
                    navigate("/doctor/products");
                  }}
                >
                  Косметичні засоби
                </div>

                <div
                  className={`sidebar-item ${active === "patients" ? "active" : ""}`}
                  onClick={() => {
                    setActive("patients");
                    navigate("/doctor/patients");
                  }}
                >
                  Пацієнти
                </div>
              </>
            )}
          </div>

          <div className="sidebar-item" onClick={() => setShowModal(true)}>
            Акаунт
          </div>
        </aside>
      </div>

      {showModal && (
        <LogoutModal
          onConfirm={handleLogoutConfirm}
          onCancel={() => setShowModal(false)}
        />
      )}
    </>
  );
}
