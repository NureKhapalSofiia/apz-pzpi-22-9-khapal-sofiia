import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import "../styles/products.css";

export default function ProductsPage() {
  const [active, setActive] = useState("products");
  const [products, setProducts] = useState([]);
  const navigate = useNavigate();
  const [selectedProductId, setSelectedProductId] = useState(null); 

useEffect(() => {
  fetchProducts();
}, []);

const fetchProducts = () => {
  const token = localStorage.getItem("token");

  fetch("http://localhost:8080/api/admin/products", {
    headers: {
      Authorization: `Bearer ${token}`
    }
  })
    .then((res) => {
      if (!res.ok) {
        throw new Error("Unauthorized");
      }
      return res.json();
    })
    .then((data) => {
      console.log("Отримані продукти:", data);
      setProducts(data);
    })
    .catch((err) => console.error("Помилка завантаження:", err));
};



const handleEdit = () => {
  if (selectedProductId) {
    navigate(`/products/edit/${selectedProductId}`);
  } else {
    alert("Оберіть продукт для редагування");
  }
};

const handleLogout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("userInfo");
  navigate("/");
};


const handleDelete = async () => {
  if (!selectedProductId) {
    alert("Оберіть продукт для видалення");
    return;
  }

  const confirm = window.confirm("Ви впевнені, що хочете видалити цей продукт?");
  if (!confirm) return;

  try {
    const res = await fetch(`http://localhost:8080/api/admin/${selectedProductId}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });

    console.log("Статус відповіді видалення:", res.status);

    if (res.ok) {
      alert("Продукт видалено");
      setSelectedProductId(null);
      fetchProducts(); // 🔁 ПОВТОРНО ПІДВАНТАЖУЄМО
    } else {
      const text = await res.text();
      console.warn("Помилка видалення:", text);
      alert("Видалення не вдалося: " + text);
    }
  } catch (err) {
    console.error("Помилка запиту:", err);
    alert("Продукт не видалено. Можливо, проблема з мережею.");
  }
};


  return (
    <div className="page-wrapper">
     <Sidebar active={active} setActive={setActive} />

      <div className="content-block" style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
  <div className="table-wrapper" style={{ maxWidth: "95%", width: "1200px" }}>
  <div style={{ maxWidth: "95%", width: "1200px" }}>
    <table className="product-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Назва</th>
                <th>Бренд</th>
                <th>Опис</th>
                <th>Категорія</th>
                <th>Сертифікат</th>
                <th>Створено</th>
                <th>Оновлено</th>
              </tr>
            </thead>
           <tbody>
  {products.map((product) => {
    console.log("ID продукту:", product.id);
    return (
      <tr
        key={product.id}
        onClick={() => setSelectedProductId(product.id)}
        className={selectedProductId === product.id ? "selected-row" : ""}
      >
        <td>{product.id}</td>
        <td>{product.name}</td>
        <td>{product.brand}</td>
        <td>{product.description}</td>
        <td>{product.category}</td>
        <td>{product.is_certified ? "Так" : "Ні"}</td>
        <td>{new Date(product.created_at).toLocaleString("uk-UA")}</td>
        <td>{new Date(product.updated_at).toLocaleString("uk-UA")}</td>
      </tr>
    );
  })}
</tbody>
          </table>
        </div>
                </div>

      </div>
    </div>
  );
}
