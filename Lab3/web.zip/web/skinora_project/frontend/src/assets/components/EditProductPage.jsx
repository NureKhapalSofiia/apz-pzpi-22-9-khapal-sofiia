import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import "../styles/editProduct.css";

export default function EditProductPage() {
  const { id } = useParams();
  const [active, setActive] = useState("products");
  const navigate = useNavigate();
  const token = localStorage.getItem("token"); // ⬅ тут


  const [name, setName] = useState("");
  const [brand, setBrand] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [isCertified, setIsCertified] = useState("");

 useEffect(() => {
    axios.get(`http://localhost:8080/api/admin/product/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((res) => {
        const data = res.data;
        setName(data.name);
        setBrand(data.brand);
        setDescription(data.description);
        setCategory(data.category);
        setIsCertified(data.is_certified ? "true" : "false");
      })
      .catch((err) => {
        console.error("Помилка при отриманні продукту:", err);
      });
  }, [id, token]);


  const handleUpdate = async () => {
    try {
      await axios.patch(`http://localhost:8080/api/admin/${id}`, {
        name,
        brand,
        description,
        category,
        is_certified: isCertified === "true",
      }, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      alert("Продукт оновлено!");
      navigate("/products");
    } catch (error) {
      console.error("Помилка при оновленні продукту:", error.response?.data || error.message);
      alert("Сталася помилка!");
    }
  };

  return (
  <div className="edit-page-wrapper">
        <Sidebar active={active} setActive={setActive} />
   
    <div className="edit-content">
      <div className="edit-title">Редагувати</div>
      <form className="edit-form" onSubmit={(e) => e.preventDefault()}>
        <input type="text" placeholder="name" value={name} onChange={(e) => setName(e.target.value)} />
        <input type="text" placeholder="brand" value={brand} onChange={(e) => setBrand(e.target.value)} />
        <textarea placeholder="description" value={description} onChange={(e) => setDescription(e.target.value)} />
        <input type="text" placeholder="category" value={category} onChange={(e) => setCategory(e.target.value)} />
        <input type="text" placeholder="is_certified (true/false)" value={isCertified} onChange={(e) => setIsCertified(e.target.value)} />
        <button type="button" className="add-title11" onClick={handleUpdate}>
          Зберегти зміни
        </button>
      </form>
    </div>
  </div>
);

}
