import React, { useState } from "react";
import axios from "axios";
import "../styles/addProduct.css";
import Sidebar from "../components/Sidebar";
import { useNavigate } from "react-router-dom";


export default function AddProductPage() {
  const [name, setName] = useState("");
  const [brand, setBrand] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [isCertified, setIsCertified] = useState("");
  const navigate = useNavigate();
const [active, setActive] = useState("products");

  const handleSubmit = async () => {
const userInfo = JSON.parse(localStorage.getItem("userInfo"));
  const token = localStorage.getItem("token");

  if (!userInfo || !token) {
    alert("Користувач не авторизований. Спробуйте увійти знову.");
    navigate("/");
    return;
  }

  const adminId = userInfo.id;

  try {
    await axios.post("http://localhost:8080/api/admin/product", {
      name,
      brand,
      description,
      category,
      isCertified: isCertified === "true",
      adminId,
    }, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    alert("Продукт створено!");
    navigate("/products");
  } catch (error) {
    console.error("Помилка при створенні продукту:", error.response?.data || error.message);
    alert("Сталася помилка!");
  }
};



  return (
    <div className="add-page-wrapper">
           <Sidebar active={active} setActive={setActive} />
      
      <div className="add-content">
        <div className="add-title">Додати</div>
        <form className="add-form" onSubmit={(e) => e.preventDefault()}>
          <input type="text" placeholder="name" value={name} onChange={(e) => setName(e.target.value)} />
          <input type="text" placeholder="brand" value={brand} onChange={(e) => setBrand(e.target.value)} />
          <textarea placeholder="description" value={description} onChange={(e) => setDescription(e.target.value)} />
<select value={category} onChange={(e) => setCategory(e.target.value)} className="dropdown-input">
  <option value="">Оберіть категорію</option>
  <option value="cleanser">cleanser</option>
  <option value="cream">cream</option>
  <option value="mask">mask</option>
  <option value="pads">pads</option>
  <option value="serum">serum</option>
  <option value="spf">spf</option>
  <option value="toner">toner</option>
</select>
<select value={isCertified} onChange={(e) => setIsCertified(e.target.value)} className="dropdown-input">
  <option value="">Виберіть сертифікованість</option>
  <option value="true">Так</option>
  <option value="false">Ні</option>
</select>
          <button type="button" className="add-title11" onClick={handleSubmit}>
            Зберегти
          </button>
        </form>
      </div>
    </div>
  );
}
