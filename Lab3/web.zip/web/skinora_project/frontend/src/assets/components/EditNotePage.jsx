import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import "../styles/doctor.css";

export default function EditNotePage() {
  const { patientId } = useParams();
  const [note, setNote] = useState("");
  const [active, setActive] = useState("patients");
  const navigate = useNavigate();

  const fetchNote = async () => {
    const token = localStorage.getItem("token");
    const res = await fetch(`http://localhost:8080/api/doctor/${patientId}/patients/${patientId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (res.ok) {
      const data = await res.json();
      setNote(data.notes || "");
    }
  };

  const handleSave = async () => {
    const token = localStorage.getItem("token");

    const res = await fetch(
      `http://localhost:8080/api/doctor/patients/${patientId}/note?note=${encodeURIComponent(note)}`,
      {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (res.ok) {
      alert("Нотатку оновлено!");
      navigate("/doctor/patients");    } else {
      alert("Помилка при оновленні нотатки.");
    }
  };

  useEffect(() => {
    fetchNote();
  }, []);

  return (
    <div className="page-wrapper" style={{ display: "flex" }}>
      <Sidebar active={active} setActive={setActive} />
      <div className="content-block centered-content" style={{ flex: 1, padding: "30px" }}>
        <div className="add-title">Редагувати нотатку</div>

        <textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Введіть нову нотатку..."
          style={{
            width: "80%",
            height: "200px",
            borderRadius: "20px",
            padding: "15px",
            fontSize: "16px",
            border: "1px solid #C5BAFF",
            background: "#fff",
            color: "#2D1B69",
            fontFamily: "monospace",
            marginBottom: "20px",
          }}
        />

        <button className="action-button" onClick={handleSave}>
          Зберегти
        </button>
      </div>
    </div>
  );
}
